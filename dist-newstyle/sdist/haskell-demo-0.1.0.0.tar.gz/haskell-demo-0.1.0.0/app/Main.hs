module Main where

import System.Random 
import Data.List (nub, sortOn)
{-
    (Mark, Number)
-}
data Card = Card { mark :: Char, number :: Int } deriving Show

getNubRandomRs :: RandomGen g => g -> (Int, Int) -> [Int]
getNubRandomRs g (l, h) = take (abs (h - l) + 1) $ nub $ randomRs (l, h) g
shuffle :: RandomGen g => g -> [a] -> [a]
shuffle _ [] = []
shuffle g xs = fmap fst $ sortOn snd $ zip xs rs
    where
        rs = getNubRandomRs g (1, length xs)
stringToInt :: String -> [Int]
stringToInt s = read s
main :: IO ()
main = do
    let cards = [Card x y | x <- ['S', 'H', 'D', 'K'], y <- [1..13]]
    g <- getStdGen
    let shuffled_cards = shuffle g cards
    let inithand = take 5 shuffled_cards
    putStrLn "your initial hand is"
    print inithand
    putStrLn "select cards -- Int"
    string <- getLine
    let x = stringToInt string
    print x
    